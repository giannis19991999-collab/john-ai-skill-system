# Product Scorecard

| Dimension | Evidence / notes | Rating (1–5) | Confidence |
|---|---|---:|---|
| Demand | | | |
| Customer pain/desire | | | |
| Competitive intensity | | | |
| Differentiation | | | |
| Demonstrability in short video | | | |
| Supplier reliability | | | |
| Shipping/returns | | | |
| Gross contribution | | | |
| Compliance/IP risk | | | |

## Decision
Go / Test / No-go

## Biggest unresolved risk
-

## Cheapest meaningful test
-

## Pass criteria
-

## Stop criteria
-
