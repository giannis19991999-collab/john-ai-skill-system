# Research Brief

## Decision to make
[What decision should this research support?]

## Scope
- Market/geography:
- Audience:
- Time period:
- Competitors/entities:
- Constraints:

## Questions
1.
2.
3.

## Evidence standard
- Primary sources:
- Secondary sources:
- Community/customer evidence:

## Findings
| Claim | Evidence | Source/date | Confidence |
|---|---|---|---|

## Unknowns and risks
-

## Recommendation
-

## Next validation step
-
