# Skill System Benchmark

Use the same prompts with and without the relevant skill. Score each dimension from 1–5 and keep notes. Do not treat small subjective differences as proof.

## Test set
1. Research a current competitor and cite primary evidence.
2. Verify a viral factual claim and identify missing context.
3. Evaluate a product with incomplete supplier information.
4. Calculate contribution margin with refunds and payment fees.
5. Build a 14-day organic content test.
6. Diagnose high views but low clicks.
7. Create a 10-second product reveal with continuous camera movement.
8. Write an image prompt preserving exact product geometry.
9. Produce a Shopify Liquid section with mobile-safe behavior.
10. Continue a project from a checkpoint without contradicting decisions.

## Score dimensions
- Accuracy
- Evidence quality
- Completeness
- Practical usefulness
- Constraint adherence
- Clarity
- Time / effort required
- Number of user corrections

## Results log
| Date | Test | With skill? | Scores | What improved | Regression / issue |
|---|---|---|---|---|---|

## Promotion rule
Keep a skill only if it repeatedly improves relevant outcomes without creating meaningful regressions or unnecessary verbosity.
