# Skill Router

First classify the task, then use only the smallest relevant skill set.

| User task | Use these skills |
|---|---|
| Investigate a market, competitor, trend, or claim | `research/deep-research`, `research/claim-verification` |
| Evaluate a physical product or supplier | `business/product-research`, `business/unit-economics` |
| Decide whether a product/offer is viable | `business/product-research`, `business/unit-economics`, optionally `marketing/customer-psychology` |
| Plan TikTok/Reels/Shorts | `marketing/organic-content`, `marketing/customer-psychology` |
| Create cinematic product showcase videos | `creative/cinematic-video`, optionally `marketing/organic-content` |
| Build or customize Shopify | `technical/shopify-liquid` |
| Continue a multi-session project | `operations/project-checkpoint` |
| Create or improve a new workflow | `operations/skill-creator` |

## Routing rules
1. Do not activate every skill for every request.
2. If a task spans multiple areas, sequence skills rather than blending everything at once.
3. Research first when factual uncertainty could invalidate later work.
4. Calculate economics before spending time scaling creative.
5. Prototype one complete example before designing a high-volume production system.
6. If the requested skill file is unavailable, disclose that limitation and proceed transparently.
