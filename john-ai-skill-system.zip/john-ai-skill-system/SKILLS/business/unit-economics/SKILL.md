---
name: unit-economics
description: Calculate realistic per-order economics and break-even requirements for e-commerce offers.
---

# E-commerce Unit Economics Skill

## Collect or explicitly assume
- Selling price
- Product cost
- Shipping and packaging
- Payment processing and currency conversion
- Shopify/platform allocation
- Refund and return allowance
- Chargeback/fraud allowance
- Duties, VAT, sales tax, or other taxes as applicable
- Discounts and affiliate/creator commissions
- Advertising cost per purchase, if paid
- Monthly fixed costs and expected order volume

## Calculations
Contribution before acquisition = selling price - variable costs excluding acquisition.
Contribution after acquisition = contribution before acquisition - CAC.
Break-even ROAS = ad spend / revenue at zero contribution; derive from actual contribution margin, not generic benchmarks.
Break-even orders = monthly fixed costs / contribution per order.

Show a conservative, base, and optimistic scenario. Do not bury assumptions. Flag missing data. Do not call revenue "profit".
