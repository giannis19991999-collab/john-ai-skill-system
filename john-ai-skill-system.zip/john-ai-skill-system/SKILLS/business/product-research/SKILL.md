---
name: product-research
description: Evaluate dropshipping and e-commerce product opportunities, customer demand, competitors, differentiation, sourcing, and operational risk.
---

# Product Research Skill

## Workflow
1. Define target country, customer, use case, and price range.
2. Identify the problem/desire and evidence that customers spend money to solve it.
3. Examine direct competitors, substitutes, positioning, offers, reviews, and complaints.
4. Mine customer language from reviews, forums, Reddit, and social comments. Treat anecdotes as signals, not market-size proof.
5. Verify supplier identity, product specifications, variants, shipping origin, delivery estimates, tracking, return handling, and quality evidence.
6. Identify legal, safety, IP, platform, and advertising-policy risks.
7. Assess differentiation that can be demonstrated honestly.
8. Recommend a low-cost validation test before committing.

## Required output
- Target buyer and buying trigger
- Demand evidence
- Competitor map
- Customer objections and desired outcomes
- Supplier and fulfillment risks
- Differentiation angle
- Validation plan and pass/fail criteria
- Go / Test / No-go recommendation

Never confuse social views with purchase intent. Never assume a supplier listing proves quality or reliable fulfillment.
