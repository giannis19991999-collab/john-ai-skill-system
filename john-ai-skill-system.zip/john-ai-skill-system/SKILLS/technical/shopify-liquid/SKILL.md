---
name: shopify-liquid
description: Plan and implement Shopify theme customizations using Liquid, CSS, JavaScript, and theme-safe practices.
---

# Shopify Liquid Skill

1. Identify theme name/version and the exact page/section.
2. Ask for relevant existing code or inspect provided files before replacing anything.
3. Prefer the smallest isolated change.
4. Explain where code belongs and whether it replaces or supplements existing code.
5. Use Shopify Liquid conventions and avoid unsupported assumptions about theme internals.
6. Consider mobile layout, accessibility, performance, and theme editor compatibility.
7. Avoid exposing secrets or private customer data.
8. Provide a rollback path and testing checklist.

For code changes, include complete code where practical, exact insertion location, dependencies, and verification steps. Do not claim the change was applied to the live store unless a connected tool confirms it.
