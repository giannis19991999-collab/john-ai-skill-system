---
name: project-checkpoint
description: Preserve decisions, progress, constraints, and next actions across long-running projects.
---

# Project Checkpoint Skill

At the end of substantial work, create a checkpoint with:

## Project
Name and objective.

## Current state
What is completed and what is not.

## Decisions
Decision, rationale, date, and whether reversible.

## Constraints
Budget, tools, deadlines, market, quality requirements, and known limitations.

## Evidence
Metrics, sources, files, and observations. Distinguish measured data from estimates.

## Open questions
Only unresolved questions that materially affect the next step.

## Next action
One concrete next action, owner, and success condition.

Do not silently overwrite old decisions. Mark superseded decisions and explain why.
