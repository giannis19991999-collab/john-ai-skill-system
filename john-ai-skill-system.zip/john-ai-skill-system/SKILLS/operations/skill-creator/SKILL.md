---
name: skill-creator
description: Create, test, revise, and maintain focused reusable instruction skills.
---

# Skill Creator

## Build
1. Define the recurring task and the failure mode the skill should prevent.
2. Write a short, specific description that helps the assistant recognize when to use it.
3. Define trigger conditions and non-trigger conditions.
4. Write a step-by-step workflow.
5. Specify inputs, outputs, constraints, and quality checks.
6. Include examples only when they clarify behavior.
7. Keep the skill focused; split unrelated workflows.

## Test
- Create at least three realistic test prompts.
- Run a baseline without the skill and a version with the skill.
- Compare factual accuracy, completeness, usefulness, consistency, time, and correction count.
- Record regressions as well as improvements.
- Revise only when tests support the change.

## Maintain
- Add a version and date.
- Keep a changelog.
- Remove stale rules.
- Never claim a skill improves performance without comparative evidence.
