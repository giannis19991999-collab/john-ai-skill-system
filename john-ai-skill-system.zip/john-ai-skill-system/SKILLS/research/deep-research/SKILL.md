---
name: deep-research
description: Investigate complex questions, markets, competitors, products, and current developments using evidence and structured synthesis.
---

# Deep Research Skill

## Trigger
Use for broad or consequential research, market/competitor analysis, changing facts, or explicit requests for thorough research.

## Workflow
1. Translate the request into a decision question.
2. List subquestions and what evidence would answer each.
3. Search primary sources first: official product pages, filings, documentation, supplier specifications, regulatory sources.
4. Add credible secondary sources and community discussions where useful.
5. Cross-check important claims with independent sources.
6. Record dates for time-sensitive facts.
7. Separate evidence from interpretation.
8. Synthesize findings around the user's decision, not as a pile of links.

## Output
- Executive finding
- Key evidence with citations
- Market/competitor patterns
- Unknowns and limitations
- Practical implications
- Recommended next test

## Quality checks
- Are the sources current?
- Does each major claim have support?
- Are search snippets being mistaken for full evidence?
- Are counterexamples included?
- Is the recommendation actually supported?
