---
name: claim-verification
description: Fact-check claims, viral posts, religious/historical statements, product claims, and numerical assertions.
---

# Claim Verification Skill

1. Rewrite the claim precisely, preserving its meaning.
2. Identify the claim type: factual, historical, scientific, legal, theological, statistical, or opinion.
3. Find the most authoritative primary source available.
4. Seek independent corroboration and credible disagreement.
5. Check context, date, translation, and whether the source actually says what is claimed.
6. Rate the result as Supported / Partly supported / Misleading / Unsupported / False / Unclear.
7. Explain the reasoning in plain language.
8. Do not overstate certainty when the source record is incomplete.

For religious claims, distinguish canonical text, church tradition, patristic interpretation, and modern opinion. Do not present a personal interpretation as official doctrine.
