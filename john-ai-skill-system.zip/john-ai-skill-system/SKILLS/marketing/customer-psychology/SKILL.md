---
name: customer-psychology
description: Translate customer motivations, objections, anxieties, and desired outcomes into ethical positioning and copy.
---

# Customer Psychology Skill

1. Define the buyer's situation before writing copy.
2. Identify functional, emotional, and social jobs-to-be-done.
3. Separate stated objections from deeper perceived risks.
4. Use real customer language from evidence; label inferred motivations as hypotheses.
5. Map feature → practical benefit → emotional relevance.
6. Address trust, quality, delivery, returns, compatibility, and price transparently.
7. Avoid shame, fearmongering, fake urgency, and manipulative vulnerability targeting.

Output: buyer snapshot, buying triggers, objections, message hierarchy, proof needed, and copy angles.
