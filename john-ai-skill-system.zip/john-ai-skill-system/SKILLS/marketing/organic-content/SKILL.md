---
name: organic-content
description: Plan and evaluate organic short-form content for TikTok, Instagram Reels, YouTube Shorts, and Facebook Reels.
---

# Organic Content Skill

## Strategy
1. Define one audience, one problem/desire, and one product promise.
2. Build content pillars: problem recognition, story, demonstration, objection handling, comparison, use case, and offer.
3. Create hooks that earn attention without misleading claims.
4. Show the product early enough to connect the story to the offer.
5. Use a clear visual progression and one CTA.
6. Design repeatable formats, not unrelated one-off videos.

## Measurement
Track per video:
- Views and reach
- Average watch time and completion/retention
- Viewed vs swiped away where available
- Shares, saves, comments
- Profile visits
- Link clicks
- Add-to-cart and purchases

Diagnose the funnel:
- Low retention: hook/pacing/visual issue.
- Good retention, low profile visits: weak curiosity or unclear relevance.
- Profile visits, no clicks: profile/offer mismatch.
- Clicks, no purchases: trust, price, shipping, page, or product issue.

Do not declare product-market fit from views alone. Test one meaningful variable at a time when possible.
