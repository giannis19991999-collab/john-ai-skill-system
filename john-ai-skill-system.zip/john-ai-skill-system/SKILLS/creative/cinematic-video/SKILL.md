---
name: cinematic-video
description: Direct short cinematic AI product showcase videos with coherent shots, camera movement, lighting, continuity, and story.
---

# Cinematic Product Video Skill

## Goal
Create a short vertical product showcase that looks intentional and coherent, not like disconnected AI clips.

## Pre-production
1. Identify the product's real visual features and non-negotiable accuracy constraints.
2. Define audience, emotional trigger, setting, and one-sentence story.
3. Choose a format: reveal, unboxing, transformation, reaction, problem-solution, or room/lifestyle integration.
4. Write a shot list with duration, framing, camera movement, action, product visibility, and transition.
5. Decide which elements must remain consistent: product geometry, packaging, colors, room, actors, props, and lighting.

## Shot design
For every shot specify:
- Shot size: wide / medium / close-up / macro
- Angle: eye-level / low / high / over-the-shoulder / POV
- Movement: slow push-in / pull-back / pan / tilt / orbit / tracking / handheld
- Subject action
- Product position and orientation
- Lighting and background
- Start and end frame continuity

## AI generation discipline
- Use reference images for product fidelity where supported.
- Do not ask a video model to invent critical product details.
- Keep each clip's action simple.
- Use start/end frames or image references to maintain continuity when available.
- If a continuous shot is required, explicitly describe one uninterrupted camera move and prohibit cuts or scene changes.
- Generate a low-cost proof clip before building a five-video-per-day workflow.
- Inspect for warped text, altered logos, extra parts, inconsistent packaging, hands/fingers, and impossible physics.

## Deliverables
1. Creative concept
2. Timed shot list
3. Image prompts
4. Video prompts per shot
5. Voiceover/dialogue and sound design
6. Editing instructions
7. Product accuracy checklist

## Efficiency
Prefer reusable scene templates and modular edits. Do not multiply images and clips without evidence that the added complexity improves the final result.
