# ChatGPT Setup Guide

## Recommended setup
Create a ChatGPT Project named **Personal AI Skill System** or a project dedicated to a specific business area.

### Project-level instructions
Copy the contents of `CHATGPT_PROJECT_INSTRUCTIONS.md` into the Project instructions field.

### Project sources
For a general-purpose project, add:
- `CORE/CORE_RULES.md`
- `ROUTER/ALL_SKILLS.md`
- The specific specialist skill files you expect to use.

For focused projects, use only the relevant files:
- E-commerce: `SKILLS/business/product-research/SKILL.md`, `SKILLS/business/unit-economics/SKILL.md`
- Organic marketing: `SKILLS/marketing/organic-content/SKILL.md`, `SKILLS/marketing/customer-psychology/SKILL.md`
- AI video: `SKILLS/creative/cinematic-video/SKILL.md`
- Shopify: `SKILLS/technical/shopify-liquid/SKILL.md`
- Research: `SKILLS/research/deep-research/SKILL.md`, `SKILLS/research/claim-verification/SKILL.md`

## Important limitations
- A GitHub repository is storage and version control, not automatic ChatGPT memory.
- Uploading a `SKILL.md` as a Project source does not make it a native installed Skill.
- Project instructions should tell ChatGPT how to use the sources, but availability and behavior can vary by ChatGPT feature.
- When a task depends on current facts, use available web research rather than relying on old files.
- Do not upload private credentials, API keys, passwords, payment data, or sensitive customer information.

## Suggested workflow
1. Start a chat inside the relevant Project.
2. State the desired outcome and constraints.
3. ChatGPT should select the relevant workflow using `ROUTER/ALL_SKILLS.md`.
4. Ask for a checkpoint at the end of substantial work.
5. Save the checkpoint in the matching project file or keep it in the Project conversation.
