# Changelog

## 0.1.0 — Initial system
- Created ChatGPT-first project architecture.
- Added core rules and skill router.
- Added research, business, marketing, creative, Shopify, and project-operations skills.
- Added reusable templates and benchmark.
- Explicitly documented that repository files are not automatically installed into ChatGPT.
