# Personal AI Skill System

A practical, ChatGPT-first operating system for research, e-commerce, organic marketing, AI video production, Shopify work, and long-running projects.

## What this is
This repository stores reusable instructions and workflows. It does **not** train a model or guarantee that ChatGPT automatically loads every skill. Use the files as Project instructions, Project sources, or paste the relevant skill into a conversation when needed.

## Start here
1. Read `CHATGPT_SETUP.md`.
2. Add `CHATGPT_PROJECT_INSTRUCTIONS.md` to the ChatGPT Project instructions.
3. Upload `CORE/CORE_RULES.md` and `ROUTER/ALL_SKILLS.md` as Project sources.
4. Upload only the specialist skills relevant to that Project. Avoid loading everything into every chat.
5. Keep project decisions and progress in `PROJECTS/` using the checkpoint template.

## Design principles
- Accuracy before confidence.
- Verify current claims with sources when freshness matters.
- Separate facts, assumptions, estimates, and recommendations.
- Challenge weak ideas; do not flatter or agree automatically.
- Optimize for practical execution and limited resources.
- Do not invent tool access, completed actions, sales, testimonials, or evidence.
- Prefer small workflows that can be tested and improved.

## Folder map
- `CORE/`: global behavior and quality standards.
- `ROUTER/`: task classification and skill selection.
- `SKILLS/`: specialist workflows.
- `PROJECTS/`: reusable project state templates.
- `EVALUATION/`: benchmark and review process.
- `TEMPLATES/`: research, product, video, and decision templates.

## Versioning
Update `CHANGELOG.md` whenever a rule or workflow changes. Record what changed, why, and what evidence justified it.
